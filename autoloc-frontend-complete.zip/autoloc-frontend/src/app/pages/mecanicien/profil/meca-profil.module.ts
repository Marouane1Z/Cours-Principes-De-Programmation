import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MecaProfilComponent } from './meca-profil.component';

@NgModule({
  declarations: [MecaProfilComponent],
  imports: [CommonModule, FormsModule, RouterModule.forChild([{ path: '', component: MecaProfilComponent }])]
})
export class MecaProfilModule {}
