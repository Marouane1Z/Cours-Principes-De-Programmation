import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meca-profil',
  templateUrl: './meca-profil.component.html',
  styleUrls: ['./meca-profil.component.scss']
})
export class MecaProfilComponent implements OnInit {
  ngOnInit(): void {}
}
