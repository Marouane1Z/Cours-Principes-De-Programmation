import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MecaDashboardComponent } from './meca-dashboard.component';

@NgModule({
  declarations: [MecaDashboardComponent],
  imports: [CommonModule, FormsModule, RouterModule.forChild([{ path: '', component: MecaDashboardComponent }])]
})
export class MecaDashboardModule {}
