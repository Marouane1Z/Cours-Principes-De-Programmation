import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MecaOrdresComponent } from './meca-ordres.component';

@NgModule({
  declarations: [MecaOrdresComponent],
  imports: [CommonModule, FormsModule, RouterModule.forChild([{ path: '', component: MecaOrdresComponent }])]
})
export class MecaOrdresModule {}
