import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ClientNotificationsComponent } from './client-notifications.component';

@NgModule({
  declarations: [ClientNotificationsComponent],
  imports: [CommonModule, FormsModule, RouterModule.forChild([{ path: '', component: ClientNotificationsComponent }])]
})
export class ClientNotificationsModule {}
