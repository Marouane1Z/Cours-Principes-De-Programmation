import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ClientProfilComponent } from './client-profil.component';

@NgModule({
  declarations: [ClientProfilComponent],
  imports: [CommonModule, FormsModule, RouterModule.forChild([{ path: '', component: ClientProfilComponent }])]
})
export class ClientProfilModule {}
