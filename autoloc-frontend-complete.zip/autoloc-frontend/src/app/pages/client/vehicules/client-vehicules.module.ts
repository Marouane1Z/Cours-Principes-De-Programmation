import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ClientVehiculesComponent } from './client-vehicules.component';

@NgModule({
  declarations: [ClientVehiculesComponent],
  imports: [CommonModule, FormsModule, RouterModule.forChild([{ path: '', component: ClientVehiculesComponent }])]
})
export class ClientVehiculesModule {}
