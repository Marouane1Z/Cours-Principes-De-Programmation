import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ClientReservationsComponent } from './client-reservations.component';

@NgModule({
  declarations: [ClientReservationsComponent],
  imports: [CommonModule, FormsModule, RouterModule.forChild([{ path: '', component: ClientReservationsComponent }])]
})
export class ClientReservationsModule {}
