import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ClientDashboardComponent } from './client-dashboard.component';

@NgModule({
  declarations: [ClientDashboardComponent],
  imports: [CommonModule, FormsModule, RouterModule.forChild([{ path: '', component: ClientDashboardComponent }])]
})
export class ClientDashboardModule {}
