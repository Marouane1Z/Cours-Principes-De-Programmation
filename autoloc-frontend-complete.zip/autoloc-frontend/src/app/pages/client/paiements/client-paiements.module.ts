import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ClientPaiementsComponent } from './client-paiements.component';

@NgModule({
  declarations: [ClientPaiementsComponent],
  imports: [CommonModule, FormsModule, RouterModule.forChild([{ path: '', component: ClientPaiementsComponent }])]
})
export class ClientPaiementsModule {}
