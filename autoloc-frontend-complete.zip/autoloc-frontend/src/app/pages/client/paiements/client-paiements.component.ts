import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-paiements',
  templateUrl: './client-paiements.component.html',
  styleUrls: ['./client-paiements.component.scss']
})
export class ClientPaiementsComponent implements OnInit {
  ngOnInit(): void {}
}
