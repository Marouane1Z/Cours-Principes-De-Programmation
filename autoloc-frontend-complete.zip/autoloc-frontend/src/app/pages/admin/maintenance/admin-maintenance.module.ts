import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AdminMaintenanceComponent } from './admin-maintenance.component';

@NgModule({
  declarations: [AdminMaintenanceComponent],
  imports: [CommonModule, FormsModule, RouterModule.forChild([{ path: '', component: AdminMaintenanceComponent }])]
})
export class AdminMaintenanceModule {}
