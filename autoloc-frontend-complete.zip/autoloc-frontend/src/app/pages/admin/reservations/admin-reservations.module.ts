import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AdminReservationsComponent } from './admin-reservations.component';

@NgModule({
  declarations: [AdminReservationsComponent],
  imports: [CommonModule, FormsModule, RouterModule.forChild([{ path: '', component: AdminReservationsComponent }])]
})
export class AdminReservationsModule {}
