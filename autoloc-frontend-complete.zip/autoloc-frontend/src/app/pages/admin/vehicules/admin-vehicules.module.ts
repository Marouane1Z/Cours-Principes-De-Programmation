import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AdminVehiculesComponent } from './admin-vehicules.component';

@NgModule({
  declarations: [AdminVehiculesComponent],
  imports: [CommonModule, FormsModule, RouterModule.forChild([{ path: '', component: AdminVehiculesComponent }])]
})
export class AdminVehiculesModule {}
