import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-paiements',
  templateUrl: './admin-paiements.component.html',
  styleUrls: ['./admin-paiements.component.scss']
})
export class AdminPaiementsComponent implements OnInit {
  ngOnInit(): void {}
}
