import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AdminPaiementsComponent } from './admin-paiements.component';

@NgModule({
  declarations: [AdminPaiementsComponent],
  imports: [CommonModule, FormsModule, RouterModule.forChild([{ path: '', component: AdminPaiementsComponent }])]
})
export class AdminPaiementsModule {}
