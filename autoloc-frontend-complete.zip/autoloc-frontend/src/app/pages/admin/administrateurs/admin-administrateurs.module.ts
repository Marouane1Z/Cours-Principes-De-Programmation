import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AdminAdministrateursComponent } from './admin-administrateurs.component';

@NgModule({
  declarations: [AdminAdministrateursComponent],
  imports: [CommonModule, FormsModule, RouterModule.forChild([{ path: '', component: AdminAdministrateursComponent }])]
})
export class AdminAdministrateursModule {}
