import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AdminClientsComponent } from './admin-clients.component';

@NgModule({
  declarations: [AdminClientsComponent],
  imports: [CommonModule, FormsModule, RouterModule.forChild([{ path: '', component: AdminClientsComponent }])]
})
export class AdminClientsModule {}
