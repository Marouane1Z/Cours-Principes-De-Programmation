import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AdminRapportsComponent } from './admin-rapports.component';

@NgModule({
  declarations: [AdminRapportsComponent],
  imports: [CommonModule, FormsModule, RouterModule.forChild([{ path: '', component: AdminRapportsComponent }])]
})
export class AdminRapportsModule {}
