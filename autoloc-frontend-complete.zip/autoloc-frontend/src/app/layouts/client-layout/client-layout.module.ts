import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ClientLayoutComponent } from './client-layout.component';

@NgModule({
  declarations: [ClientLayoutComponent],
  imports: [
    CommonModule,
    RouterModule.forChild([
      {
        path: '',
        component: ClientLayoutComponent,
        children: [
          { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
          { path: 'dashboard', loadChildren: () => import('../../pages/client/dashboard/client-dashboard.module').then(m => m.ClientDashboardModule) },
          { path: 'vehicules', loadChildren: () => import('../../pages/client/vehicules/client-vehicules.module').then(m => m.ClientVehiculesModule) },
          { path: 'reservations', loadChildren: () => import('../../pages/client/reservations/client-reservations.module').then(m => m.ClientReservationsModule) },
          { path: 'notifications', loadChildren: () => import('../../pages/client/notifications/client-notifications.module').then(m => m.ClientNotificationsModule) },
          { path: 'profil', loadChildren: () => import('../../pages/client/profil/client-profil.module').then(m => m.ClientProfilModule) },
          { path: 'paiements', loadChildren: () => import('../../pages/client/paiements/client-paiements.module').then(m => m.ClientPaiementsModule) }
        ]
      }
    ])
  ]
})
export class ClientLayoutModule {}
