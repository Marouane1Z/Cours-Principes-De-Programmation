import { Component } from '@angular/core';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-mecanicien-layout',
  templateUrl: './mecanicien-layout.component.html',
  styleUrls: ['./mecanicien-layout.component.scss']
})
export class MecanicienLayoutComponent {
  constructor(public auth: AuthService) {}
}
