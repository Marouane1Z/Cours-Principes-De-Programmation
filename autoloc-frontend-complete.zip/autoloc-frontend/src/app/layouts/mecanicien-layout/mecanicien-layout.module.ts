import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MecanicienLayoutComponent } from './mecanicien-layout.component';

@NgModule({
  declarations: [MecanicienLayoutComponent],
  imports: [
    CommonModule,
    RouterModule.forChild([
      {
        path: '',
        component: MecanicienLayoutComponent,
        children: [
          { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
          { path: 'dashboard', loadChildren: () => import('../../pages/mecanicien/dashboard/meca-dashboard.module').then(m => m.MecaDashboardModule) },
          { path: 'ordres', loadChildren: () => import('../../pages/mecanicien/ordres/meca-ordres.module').then(m => m.MecaOrdresModule) },
          { path: 'profil', loadChildren: () => import('../../pages/mecanicien/profil/meca-profil.module').then(m => m.MecaProfilModule) }
        ]
      }
    ])
  ]
})
export class MecanicienLayoutModule {}
