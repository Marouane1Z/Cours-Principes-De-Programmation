import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AdminLayoutComponent } from './admin-layout.component';

@NgModule({
  declarations: [AdminLayoutComponent],
  imports: [
    CommonModule,
    RouterModule.forChild([
      {
        path: '',
        component: AdminLayoutComponent,
        children: [
          { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
          { path: 'dashboard', loadChildren: () => import('../../pages/admin/dashboard/admin-dashboard.module').then(m => m.AdminDashboardModule) },
          { path: 'vehicules', loadChildren: () => import('../../pages/admin/vehicules/admin-vehicules.module').then(m => m.AdminVehiculesModule) },
          { path: 'clients', loadChildren: () => import('../../pages/admin/clients/admin-clients.module').then(m => m.AdminClientsModule) },
          { path: 'reservations', loadChildren: () => import('../../pages/admin/reservations/admin-reservations.module').then(m => m.AdminReservationsModule) },
          { path: 'paiements', loadChildren: () => import('../../pages/admin/paiements/admin-paiements.module').then(m => m.AdminPaiementsModule) },
          { path: 'maintenance', loadChildren: () => import('../../pages/admin/maintenance/admin-maintenance.module').then(m => m.AdminMaintenanceModule) },
          { path: 'rapports', loadChildren: () => import('../../pages/admin/rapports/admin-rapports.module').then(m => m.AdminRapportsModule) },
          { path: 'administrateurs', loadChildren: () => import('../../pages/admin/administrateurs/admin-administrateurs.module').then(m => m.AdminAdministrateursModule) }
        ]
      }
    ])
  ]
})
export class AdminLayoutModule {}
